/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2021 Xilinx, Inc. */

#ifndef __OOF_TEST_OOF_FILTERS_DEPS_H__
#define __OOF_TEST_OOF_FILTERS_DEPS_H__

extern bool cplane_use_prefsrc_as_local;

#endif
