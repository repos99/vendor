/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2022 Xilinx, Inc. */

#include "../oof_test.h"

int test_sanity_no5tuple()
{
  return __test_sanity(1);
}