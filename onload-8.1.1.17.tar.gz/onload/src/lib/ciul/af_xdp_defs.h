/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2020 Xilinx, Inc. */
#ifndef	AF_XDP_DEFS_H
#define	AF_XDP_DEFS_H

#include <ci/driver/efab/hardware/af_xdp.h>

#endif /* AF_XDP_DEFS_H */
